ctrl_c() {

	echo
	echo "${Red} Exiting and cleaning up..."
	sleep 0.5
	
	if [ -n "$yaourt_user" ]; then
		sed -i 's!'$yaourt_user' ALL = NOPASSWD: /usr/bin/makepkg, /usr/bin/pacman!!' "$ARCH"/etc/sudoers
		arch-chroot "$ARCH" /bin/bash -c "userdel -r $yaourt_user" &> /dev/null
	fi
	
	unset input
	rm /tmp/chroot_dir.var &> /dev/null
	clear
	reboot_system

}