load_log() {
	
	{	int=1
		pos=1
		pri=$(<<<"$pri" sed 's/\..*$//')
		pri=$((pri*2))
		while (true)
    	    do
    	        proc=$(ps | grep "$pid")
    	        if [ "$?" -gt "0" ]; then break; fi
    	        sleep 0.5
    	        if [ "$pos" -eq "$pri" ]; then
    	        	pos=0
    	        	if [ "$int" -lt "100" ]; then
    	        		int=$((int+1))
    	        	fi
    	        fi
    	        log=$(tail -n 1 "$tmpfile" | sed 's/.pkg.tar.xz//')
    	        echo "$int"
    	        echo -e "XXX$msg \n \Z1> \Z2$log\Zn\nXXX"
    	        pos=$((pos+1))
    	    done
            echo 100
            sleep 1
	} | dialog --gauge "$msg" 10 79 0

}